This package include star sprites for collectibles.

Included:
    PNG file with all stars
    Separate PNG files (for each star)

Your support is appreciated:
    https://www.paypal.me/pix3lcat

Thank you :)
